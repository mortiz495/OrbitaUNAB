/* =====================================================
   Órbita UNAB - app.js
   Este archivo lo usan TODAS las páginas.
   Cada página dice cuál es en su etiqueta <body data-pagina="...">
   y abajo, en la sección 9, se ejecuta lo que le corresponde.

   Los datos se guardan en el navegador (localStorage),
   por eso no hace falta servidor ni base de datos.
   ===================================================== */


/* =====================================================
   1. DATOS DEL PORTAL
   Todo lo que dice "CAMBIAR" se puede reemplazar
   por información real sin tocar el resto del código.
   ===================================================== */

var PERIODO = '2026-2';

// Cortes del semestre. Las fechas salen de la línea de tiempo de semestre.html
// Si el semestre tiene 3 cortes, se agrega otra línea y se ajustan las metas.
var CORTES = [
  { nombre: 'Corte 1', fin: '2026-10-02', meta: 20 },
  { nombre: 'Corte 2', fin: '2026-11-20', meta: 20 }
];

// Total de horas libres (HL) del semestre = suma de las metas de los cortes
var META_HORAS = 40;

// Programas de la UNAB para sugerir al registrarse
// (CAMBIAR / VERIFICAR con la lista oficial de unab.edu.co)
var PROGRAMAS = [
  'Administración de Empresas', 'Administración Turística y Hotelera', 'Artes Audiovisuales',
  'Comunicación Social', 'Contaduría Pública', 'Derecho', 'Economía', 'Enfermería',
  'Gastronomía y Alta Cocina', 'Ingeniería Biomédica', 'Ingeniería de Mercados',
  'Ingeniería de Sistemas', 'Ingeniería en Energía', 'Ingeniería Industrial',
  'Ingeniería Mecatrónica', 'Licenciatura en Educación Infantil', 'Literatura', 'Medicina',
  'Música', 'Negocios Internacionales', 'Odontología', 'Psicología',
  'Profesional en Seguridad y Salud en el Trabajo'
];

// Actividades donde se pueden obtener horas libres.
// CAMBIAR por los eventos reales de Bienestar Universitario.
// IMAGEN: cada evento tiene su foto en el campo "foto". Guarden las fotos
// (tomadas por el grupo) en la carpeta img/ con esos mismos nombres.
var EVENTOS = [
  { id: 1, nombre: 'Jornada de lectura en voz alta', horas: 2, fecha: '2026-11-24', hora: '9:00 a. m.', lugar: 'Biblioteca', cupos: 20, foto: 'img/bibliotecaevento.jpg' },
  { id: 2, nombre: 'Charla de salud universitaria', horas: 3, fecha: '2026-11-25', hora: '2:00 p. m.', lugar: 'Auditorio (edificio L)', cupos: 30, foto: 'img/auditorio.jpg' },
  { id: 3, nombre: 'Taller de búsqueda de fuentes académicas', horas: 2, fecha: '2026-11-26', hora: '10:00 a. m.', lugar: 'Biblioteca', cupos: 25, foto: 'img/bibliotecaevento.jpg' },
  { id: 4, nombre: 'Conversatorio con egresados', horas: 3, fecha: '2026-11-27', hora: '3:00 p. m.', lugar: 'Auditorio (edificio L)', cupos: 40, foto: 'img/auditorio.jpg' },
  { id: 5, nombre: 'Club de lectura de cuentos cortos', horas: 2, fecha: '2026-11-30', hora: '4:00 p. m.', lugar: 'Biblioteca', cupos: 15, foto: 'img/bibliotecaevento.jpg' },
  { id: 6, nombre: 'Foro de emprendimiento estudiantil', horas: 4, fecha: '2026-12-01', hora: '8:00 a. m.', lugar: 'Auditorio (edificio L)', cupos: 50, foto: 'img/auditorio.jpg' }
];

// Top 10: datos de EJEMPLO (ficticios). HL por semestre: [2025-2, 2026-1, 2026-2]
var PERIODOS_TOP = [
  { valor: 'todos', texto: 'Últimos tres semestres (2025-2 a 2026-2)' },
  { valor: '0', texto: 'Semestre 2025-2' },
  { valor: '1', texto: 'Semestre 2026-1' },
  { valor: '2', texto: 'Semestre 2026-2' }
];

var TOP10 = [
  { ini: 'M. L. T.', programa: 'Ingeniería de Sistemas', semestre: 7, hl: [20, 24, 20] },
  { ini: 'J. A. R.', programa: 'Derecho', semestre: 8, hl: [18, 22, 18] },
  { ini: 'S. P. G.', programa: 'Psicología', semestre: 5, hl: [17, 21, 18] },
  { ini: 'D. C. M.', programa: 'Ingeniería Industrial', semestre: 6, hl: [16, 20, 19] },
  { ini: 'L. F. V.', programa: 'Administración de Empresas', semestre: 7, hl: [15, 19, 18] },
  { ini: 'A. N. O.', programa: 'Medicina', semestre: 5, hl: [14, 18, 18] },
  { ini: 'K. S. B.', programa: 'Ingeniería Mecatrónica', semestre: 6, hl: [14, 17, 17] },
  { ini: 'V. R. H.', programa: 'Comunicación Social', semestre: 7, hl: [13, 17, 17] },
  { ini: 'C. J. D.', programa: 'Contaduría Pública', semestre: 8, hl: [13, 16, 16] },
  { ini: 'N. M. A.', programa: 'Psicología', semestre: 6, hl: [12, 16, 16] },
  { ini: 'E. P. T.', programa: 'Enfermería', semestre: 4, hl: [10, 14, 15] },
  { ini: 'H. G. L.', programa: 'Negocios Internacionales', semestre: 3, hl: [9, 12, 14] }
];

var MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio',
             'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];


/* =====================================================
   2. HERRAMIENTAS PEQUEÑAS
   ===================================================== */

// Atajo para buscar un elemento de la página por su id
function el(id) {
  return document.getElementById(id);
}

// Pone un texto dentro de un elemento (si el elemento existe)
function poner(id, texto) {
  var elemento = el(id);
  if (elemento) { elemento.textContent = texto; }
}

// Lee un campo de formulario y le quita los espacios de los lados
function valor(id) {
  return el(id).value.trim();
}

// Leer y guardar en el navegador
function leer(clave, porDefecto) {
  var texto = localStorage.getItem(clave);
  if (texto === null) { return porDefecto; }
  return JSON.parse(texto);
}

function guardar(clave, dato) {
  localStorage.setItem(clave, JSON.stringify(dato));
}

// Evita que un texto escrito por el usuario dañe el HTML
function limpiar(texto) {
  return String(texto).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Quita tildes y mayúsculas para comparar textos al buscar
function normalizar(texto) {
  return texto.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

// '2026-11-24' -> '24 de noviembre de 2026'
function formatoFecha(iso) {
  var partes = iso.split('-');
  return parseInt(partes[2], 10) + ' de ' + MESES[parseInt(partes[1], 10) - 1] + ' de ' + partes[0];
}

// Fecha de hoy en formato '2026-11-24'
function hoy() {
  var d = new Date();
  var mes = d.getMonth() + 1;
  var dia = d.getDate();
  return d.getFullYear() + '-' + (mes < 10 ? '0' + mes : mes) + '-' + (dia < 10 ? '0' + dia : dia);
}

function primerNombre(nombre) {
  return nombre.trim().split(/\s+/)[0];
}

// 'Maikeen Eduardo Ortiz Niño' -> 'Maikeen E.'
function nombreCorto(nombre) {
  var palabras = nombre.trim().split(/\s+/);
  if (palabras.length == 1) { return palabras[0]; }
  return palabras[0] + ' ' + palabras[1].charAt(0).toUpperCase() + '.';
}

// 'Maikeen Eduardo Ortiz Niño' -> 'M. E. O.'  (para el Top 10)
function iniciales(nombre) {
  var palabras = nombre.trim().split(/\s+/).slice(0, 3);
  var resultado = [];
  for (var i = 0; i < palabras.length; i++) {
    resultado.push(palabras[i].charAt(0).toUpperCase() + '.');
  }
  return resultado.join(' ');
}

// Muestra un aviso arriba de la página (el <div id="mensaje">)
function mostrarMensaje(texto, esError) {
  var caja = el('mensaje');
  if (!caja) { return; }
  caja.textContent = texto;
  caja.className = esError ? 'mensaje mensaje-error' : 'mensaje';
  caja.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Escribe un error debajo de un campo. Devuelve true si había error.
function marcar(idError, texto) {
  el(idError).textContent = texto;
  return texto !== '';
}


/* =====================================================
   3. VALIDACIONES (las usan el registro, el perfil y el login)
   Cada función devuelve el mensaje de error, o '' si todo está bien.
   ===================================================== */

function errorNombre(nombre) {
  if (nombre.split(/\s+/).length < 2) { return 'Escribe tu nombre y tu apellido.'; }
  return '';
}

function errorCodigo(codigo) {
  if (!/^[A-Za-z][0-9]{8}$/.test(codigo)) { return 'El código estudiantil debe tener 9 caracteres: una letra y 8 números (ej. U00186745).'; }
  return '';
}

function errorPrograma(programa) {
  if (programa.length < 3) { return 'Escribe el programa que estudias.'; }
  return '';
}

function errorSemestre(semestre) {
  if (semestre === '') { return 'Elige el semestre que cursas.'; }
  return '';
}

function errorCorreo(correo) {
  if (correo === '') { return 'Escribe tu correo institucional.'; }
  if (!/^[^\s@]+@unab\.edu\.co$/i.test(correo)) { return 'Escribe un correo institucional válido, por ejemplo nombre@unab.edu.co.'; }
  return '';
}

function errorClave(clave) {
  if (clave.length < 8) { return 'La clave debe tener mínimo 8 caracteres.'; }
  return '';
}

// Llena la lista de sugerencias de programas
function llenarProgramas() {
  var html = '';
  for (var i = 0; i < PROGRAMAS.length; i++) {
    html += '<option value="' + PROGRAMAS[i] + '">';
  }
  el('listaProgramas').innerHTML = html;
}

// Llena la lista de semestres (1 a 12)
function llenarSemestres(idSelect, elegido) {
  var html = '<option value="">Selecciona tu semestre</option>';
  for (var n = 1; n <= 12; n++) {
    html += '<option value="' + n + '"' + (n == elegido ? ' selected' : '') + '>' + n + '.°</option>';
  }
  el(idSelect).innerHTML = html;
}


/* =====================================================
   4. USUARIOS Y DATOS DE CADA USUARIO
   ===================================================== */

function listaUsuarios() {
  return leer('usuarios', []);
}

function buscarUsuario(correo) {
  var lista = listaUsuarios();
  for (var i = 0; i < lista.length; i++) {
    if (lista[i].correo == correo) { return lista[i]; }
  }
  return null;
}

// El usuario que tiene la sesión iniciada (o null si no hay)
function usuarioActual() {
  var correo = localStorage.getItem('sesion');
  if (correo === null) { return null; }
  return buscarUsuario(correo);
}

// Guarda los cambios de un usuario (por ejemplo, al editar el perfil)
function actualizarUsuario(usuario) {
  var lista = listaUsuarios();
  for (var i = 0; i < lista.length; i++) {
    if (lista[i].correo == usuario.correo) { lista[i] = usuario; }
  }
  guardar('usuarios', lista);
}

// Datos del usuario actual: actividades inscritas y su historial de horas
function datos() {
  var d = leer('datos_' + usuarioActual().correo, null);
  if (d === null) { d = { inscritos: [], historial: [] }; }
  d.inscritos = d.inscritos.filter(function (id) { return buscarEvento(id) !== null; });
  return d;
}

function guardarDatos(d) {
  guardar('datos_' + usuarioActual().correo, d);
}

// Crea una cuenta de prueba la primera vez que se abre el portal.
// QUITAR esta función (y su llamada en iniciarComun) si no la quieren.
function sembrarDatos() {
  if (localStorage.getItem('usuarios') !== null) { return; }
  guardar('usuarios', [
    { nombre: 'Usuario de Prueba', codigo: 'U00123456', programa: 'Ingeniería de Sistemas', semestre: 8, correo: 'usuario@unab.edu.co', clave: '12345678' }
  ]);
  guardar('datos_usuario@unab.edu.co', {
    inscritos: [1],
    historial: [
      { id: 0, fecha: '2026-08-29', evento: 'Jornada de reciclaje', horas: 2 },
      { id: 0, fecha: '2026-09-12', evento: 'Feria de emprendimiento', horas: 3 },
      { id: 0, fecha: '2026-09-20', evento: 'Carrera ambiental', horas: 4 }
    ]
  });
  guardar('ocupados', { 1: 1 });
  guardar('resenas', [
    { evento: 'Feria de emprendimiento', estrellas: 5, comentario: 'Muy bien organizada, conocí proyectos de otros programas.', autor: 'Ian A', correo: 'irojas71@unab.edu.co' },
    { evento: 'Jornada de reciclaje', estrellas: 4, comentario: 'Llevar guantes propios ayuda; todo lo demás estuvo claro.', autor: 'Lisay V', correo: 'lmarquez481@unab.edu.co' }
  ]);
}

function cerrarSesion() {
  localStorage.removeItem('sesion');
  irA('login');
}


/* =====================================================
   5. HORAS LIBRES (HL), CORTES Y CUPOS
   ===================================================== */

function horasCumplidas(d) {
  var total = 0;
  for (var i = 0; i < d.historial.length; i++) {
    total += d.historial[i].horas;
  }
  return total;
}

// A qué corte pertenece una fecha (0 = Corte 1, 1 = Corte 2, ...)
function corteDe(fecha) {
  for (var i = 0; i < CORTES.length; i++) {
    if (fecha <= CORTES[i].fin) { return i; }
  }
  return CORTES.length - 1;
}

function horasDelCorte(d, numero) {
  var total = 0;
  for (var i = 0; i < d.historial.length; i++) {
    if (corteDe(d.historial[i].fecha) == numero) { total += d.historial[i].horas; }
  }
  return total;
}

function buscarEvento(id) {
  for (var i = 0; i < EVENTOS.length; i++) {
    if (EVENTOS[i].id == id) { return EVENTOS[i]; }
  }
  return null;
}

// Cupos que quedan = cupos del evento - personas inscritas
function cuposLibres(evento) {
  var ocupados = leer('ocupados', {});
  return evento.cupos - (ocupados[evento.id] || 0);
}

function estaInscrito(d, id) {
  return d.inscritos.indexOf(id) != -1;
}

function yaCumplido(d, id) {
  for (var i = 0; i < d.historial.length; i++) {
    if (d.historial[i].id == id) { return true; }
  }
  return false;
}

// Pinta las cifras de avance (inicio y perfil usan los mismos ids)
function pintarAvance() {
  var d = datos();
  var hechas = horasCumplidas(d);
  var faltan = Math.max(0, META_HORAS - hechas);
  var porcentaje = Math.min(100, Math.round(hechas * 100 / META_HORAS));
  poner('horasCumplidas', hechas + ' h');
  poner('horasPendientes', faltan + ' h');
  poner('porcentaje', porcentaje + ' %');
  poner('inscripcionesActivas', d.inscritos.length);
  var barra = el('barraTotal');
  if (barra) { barra.style.width = porcentaje + '%'; }
}

// Pinta una barra por cada corte
function pintarCortes(idContenedor) {
  var d = datos();
  var html = '';
  for (var i = 0; i < CORTES.length; i++) {
    var horas = horasDelCorte(d, i);
    var porcentaje = Math.min(100, Math.round(horas * 100 / CORTES[i].meta));
    html += '<p>' + CORTES[i].nombre + ' - ' + horas + ' de ' + CORTES[i].meta + ' horas ' +
            '<span class="nota">(cierra el ' + formatoFecha(CORTES[i].fin) + ')</span></p>' +
            '<div class="barra"><div style="width: ' + porcentaje + '%;"></div></div>';
  }
  el(idContenedor).innerHTML = html;
}


/* =====================================================
   6. PÁGINAS SIN SESIÓN: INICIO DE SESIÓN Y REGISTRO
   ===================================================== */

function iniciarLogin() {
  // Si viene del registro, mostramos un aviso y su correo
  var parametros = new URLSearchParams(location.search);
  if (registroNuevo !== '') {
    mostrarMensaje('Tu cuenta se creó. Ya puedes iniciar sesión.');
    el('correo').value = registroNuevo; registroNuevo = '';
  }

  el('formLogin').onsubmit = function (evento) {
    evento.preventDefault();
    var correo = valor('correo').toLowerCase();
    var clave = el('clave').value;

    var errores = 0;
    if (marcar('errorCorreo', errorCorreo(correo))) { errores++; }
    if (marcar('errorClave', clave === '' ? 'Escribe tu clave.' : '')) { errores++; }
    if (errores > 0) { return; }

    var usuario = buscarUsuario(correo);
    if (usuario === null || usuario.clave != clave) {
      mostrarMensaje('El correo o la clave no son correctos.', true);
      return;
    }
    localStorage.setItem('sesion', usuario.correo);
    irA('inicio');
  };
}

function iniciarRegistro() {
  llenarProgramas();
  llenarSemestres('semestre', '');

  el('formRegistro').onsubmit = function (evento) {
    evento.preventDefault();
    var nombre = valor('nombre');
    var codigo = valor('codigo');
    var programa = valor('programa');
    var semestre = valor('semestre');
    var correo = valor('correo').toLowerCase();
    var clave = el('clave').value;
    var clave2 = el('clave2').value;

    var errores = 0;
    if (marcar('errorNombre', errorNombre(nombre))) { errores++; }
    if (marcar('errorCodigo', errorCodigo(codigo))) { errores++; }
    if (marcar('errorPrograma', errorPrograma(programa))) { errores++; }
    if (marcar('errorSemestre', errorSemestre(semestre))) { errores++; }
    if (marcar('errorCorreo', errorCorreo(correo))) { errores++; }
    if (marcar('errorClave', errorClave(clave))) { errores++; }
    if (marcar('errorClave2', clave2 !== clave ? 'Las dos claves no son iguales.' : '')) { errores++; }

    // El correo y el código no se pueden repetir
    var lista = listaUsuarios();
    for (var i = 0; i < lista.length; i++) {
      if (lista[i].correo == correo && errorCorreo(correo) === '') {
        marcar('errorCorreo', 'Ya existe una cuenta con ese correo.'); errores++;
      }
      if (lista[i].codigo == codigo && errorCodigo(codigo) === '') {
        marcar('errorCodigo', 'Ya existe una cuenta con ese código.'); errores++;
      }
    }
    if (errores > 0) { return; }

    lista.push({ nombre: nombre, codigo: codigo, programa: programa, semestre: parseInt(semestre, 10), correo: correo, clave: clave });
    guardar('usuarios', lista);
    registroNuevo = correo; irA('login');
  };
}


/* =====================================================
   7. PÁGINAS CON SESIÓN
   ===================================================== */

/* ---------- Inicio ---------- */
function iniciarInicio() {
  poner('saludoNombre', primerNombre(usuarioActual().nombre));
  pintarAvance();

  // Próximas actividades en las que está inscrito
  var d = datos();
  var html = '';
  if (d.inscritos.length === 0) {
    html = '<p>Aún no tienes actividades inscritas.</p><a href="#lugares" class="boton">Buscar actividades</a>';
  } else {
    for (var i = 0; i < d.inscritos.length; i++) {
      var ev = buscarEvento(d.inscritos[i]);
      html += '<div class="actividad"><b>' + limpiar(ev.nombre) + '</b><br>' +
              formatoFecha(ev.fecha) + ', ' + ev.hora + ' - ' + limpiar(ev.lugar) + ' - ' + ev.horas + ' HL</div>';
    }
    html += '<div class="acciones"><a href="#lugares" class="boton boton-borde">Ver mis inscripciones</a></div>';
  }
  el('proximas').innerHTML = html;

  el('botonVerAvance').onclick = function () {
    el('avance').scrollIntoView({ behavior: 'smooth' });
  };
}

/* ---------- Mi perfil ---------- */
function pintarPerfil() {
  var u = usuarioActual();
  poner('perfilInicial', u.nombre.charAt(0).toUpperCase());
  poner('perfilNombre', u.nombre);
  poner('perfilPrograma', u.programa);
  poner('perfilCodigo', u.codigo);
  poner('perfilCorreo', u.correo);
  poner('perfilSemestre', u.semestre + '.° semestre');
  poner('perfilPeriodo', PERIODO);
  // También actualiza el encabezado
  poner('nombreUsuario', primerNombre(u.nombre));
  poner('avatar', u.nombre.charAt(0).toUpperCase());
}

function iniciarPerfil() {
  pintarPerfil();
  pintarAvance();
  pintarCortes('cortes');
  llenarProgramas();

  // Botón "Editar perfil": muestra el formulario con los datos actuales
  el('botonEditar').onclick = function () {
    var u = usuarioActual();
    el('editNombre').value = u.nombre;
    el('editPrograma').value = u.programa;
    llenarSemestres('editSemestre', u.semestre);
    el('formPerfil').classList.remove('oculto');
    el('botonEditar').classList.add('oculto');
  };

  // Botón "Cancelar": esconde el formulario sin guardar
  el('botonCancelar').onclick = function () {
    el('formPerfil').classList.add('oculto');
    el('botonEditar').classList.remove('oculto');
  };

  // Botón "Guardar cambios"
  el('formPerfil').onsubmit = function (evento) {
    evento.preventDefault();
    var errores = 0;
    if (marcar('errorEditNombre', errorNombre(valor('editNombre')))) { errores++; }
    if (marcar('errorEditPrograma', errorPrograma(valor('editPrograma')))) { errores++; }
    if (marcar('errorEditSemestre', errorSemestre(valor('editSemestre')))) { errores++; }
    if (errores > 0) { return; }

    var u = usuarioActual();
    u.nombre = valor('editNombre');
    u.programa = valor('editPrograma');
    u.semestre = parseInt(valor('editSemestre'), 10);
    actualizarUsuario(u);

    pintarPerfil();
    el('formPerfil').classList.add('oculto');
    el('botonEditar').classList.remove('oculto');
    mostrarMensaje('Tus datos se guardaron.');
  };
}

/* ---------- Lugares y eventos ---------- */

// Arma el HTML de una tarjeta de evento
function tarjetaEvento(ev, d) {
  var libres = cuposLibres(ev);
  var boton;
  if (yaCumplido(d, ev.id)) {
    boton = '<p><b>Ya cumpliste esta actividad.</b></p>';
  } else if (estaInscrito(d, ev.id)) {
    boton = '<button type="button" class="boton boton-rojo" data-accion="cancelar" data-id="' + ev.id + '">Cancelar inscripción</button>';
  } else if (libres <= 0) {
    boton = '<button type="button" class="boton" disabled>Sin cupos</button>';
  } else {
    boton = '<button type="button" class="boton" data-accion="inscribir" data-id="' + ev.id + '">Inscribirme</button>';
  }

  return '<div class="tarjeta evento">' +
    '<div class="foto"><span>Foto: ' + limpiar(ev.lugar) + '</span>' +
    '<img src="' + ev.foto + '" alt="' + limpiar(ev.lugar) + '" onerror="this.style.display=\'none\'"></div>' +
    '<span class="etiqueta">' + ev.horas + ' horas libres</span>' +
    '<h3>' + limpiar(ev.nombre) + '</h3>' +
    '<p>' + formatoFecha(ev.fecha) + ' - ' + ev.hora + '<br>' + limpiar(ev.lugar) + '<br>' +
    libres + (libres == 1 ? ' cupo disponible' : ' cupos disponibles') + '</p>' +
    boton + ' <a href="#mapa" class="nota">Ver en el mapa</a>' +
    '</div>';
}

// Muestra los eventos que coinciden con lo escrito en el buscador
function pintarEventos() {
  var d = datos();
  var escrito = el('buscar').value.trim();
  var texto = normalizar(escrito);
  var html = '';
  var total = 0;

  for (var i = 0; i < EVENTOS.length; i++) {
    var ev = EVENTOS[i];
    if (texto === '' || normalizar(ev.nombre + ' ' + ev.lugar).indexOf(texto) != -1) {
      html += tarjetaEvento(ev, d);
      total++;
    }
  }
  el('listaEventos').innerHTML = html;

  if (texto === '') {
    poner('contador', total + ' actividades disponibles.');
  } else {
    poner('contador', total + (total == 1 ? ' resultado' : ' resultados') + ' para «' + escrito + '».');
  }

  if (total === 0) {
    poner('textoSinResultados', 'No encontramos eventos con «' + escrito + '».');
    el('sinResultados').classList.remove('oculto');
  } else {
    el('sinResultados').classList.add('oculto');
  }
}

// Tabla "Mis inscripciones"
function pintarInscripciones() {
  var d = datos();
  if (d.inscritos.length === 0) {
    el('tablaInscripciones').classList.add('oculto');
    el('sinInscripciones').classList.remove('oculto');
    return;
  }
  el('tablaInscripciones').classList.remove('oculto');
  el('sinInscripciones').classList.add('oculto');

  var html = '';
  for (var i = 0; i < d.inscritos.length; i++) {
    var ev = buscarEvento(d.inscritos[i]);
    html += '<tr><td>' + formatoFecha(ev.fecha) + '<br>' + ev.hora + '</td><td>' + limpiar(ev.nombre) + '</td><td>' +
            limpiar(ev.lugar) + '</td><td>' + ev.horas + '</td><td>' +
            '<button type="button" class="boton boton-rojo pequeno" data-accion="cancelar" data-id="' + ev.id + '">Cancelar inscripción</button>' +
            '<button type="button" class="boton boton-borde pequeno" data-accion="asistir" data-id="' + ev.id + '">Marcar como asistido</button>' +
            '</td></tr>';
  }
  el('cuerpoInscripciones').innerHTML = html;
}

function inscribirse(id) {
  var d = datos();
  var ev = buscarEvento(id);
  if (estaInscrito(d, id) || yaCumplido(d, id)) { return; }
  if (cuposLibres(ev) <= 0) {
    mostrarMensaje('Ya no quedan cupos en esta actividad.', true);
    return;
  }
  d.inscritos.push(id);
  guardarDatos(d);
  var ocupados = leer('ocupados', {});
  ocupados[id] = (ocupados[id] || 0) + 1;
  guardar('ocupados', ocupados);
  mostrarMensaje('Te inscribiste en «' + ev.nombre + '».');
}

function cancelarInscripcion(id) {
  var d = datos();
  var ev = buscarEvento(id);
  d.inscritos.splice(d.inscritos.indexOf(id), 1);
  guardarDatos(d);
  var ocupados = leer('ocupados', {});
  ocupados[id] = Math.max(0, (ocupados[id] || 0) - 1);
  guardar('ocupados', ocupados);
  mostrarMensaje('Cancelaste tu inscripción en «' + ev.nombre + '». El cupo quedó libre.');
}

// DEMOSTRACIÓN: en el portal real el organizador confirma la asistencia.
// Aquí el botón lo simula: pasa la actividad al historial y suma las horas.
function marcarAsistencia(id) {
  var d = datos();
  var ev = buscarEvento(id);
  d.inscritos.splice(d.inscritos.indexOf(id), 1);
  d.historial.push({ id: ev.id, fecha: hoy(), evento: ev.nombre, horas: ev.horas });
  guardarDatos(d);
  mostrarMensaje('Se sumaron ' + ev.horas + ' horas libres a tu avance por «' + ev.nombre + '».');
}

function iniciarLugares() {
  pintarEventos();
  pintarInscripciones();

  // Un solo manejador para todos los botones de las tarjetas y de la tabla
  function alOprimir(evento) {
    var accion = evento.target.getAttribute('data-accion');
    if (accion === null) { return; }
    var id = parseInt(evento.target.getAttribute('data-id'), 10);
    if (accion == 'inscribir') { inscribirse(id); }
    if (accion == 'cancelar') { cancelarInscripcion(id); }
    if (accion == 'asistir') { marcarAsistencia(id); }
    pintarEventos();
    pintarInscripciones();
  }
  el('listaEventos').onclick = alOprimir;
  el('cuerpoInscripciones').onclick = alOprimir;

  // Buscador: al escribir, al oprimir "Buscar" o al oprimir Enter
  el('buscar').oninput = pintarEventos;
  el('formBuscar').onsubmit = function (evento) {
    evento.preventDefault();
    pintarEventos();
  };

  // Botón "Ver todos los eventos" (cuando no hay resultados)
  el('botonVerTodos').onclick = function () {
    el('buscar').value = '';
    pintarEventos();
    el('buscar').focus();
  };
}

/* ---------- Historial y reseñas ---------- */
var puntaje = 0;   // estrellas elegidas en el formulario de reseña

function pintarHistorial() {
  var d = datos();
  if (d.historial.length === 0) {
    el('tablaHistorial').classList.add('oculto');
    el('sinHistorial').classList.remove('oculto');
    return;
  }
  el('tablaHistorial').classList.remove('oculto');
  el('sinHistorial').classList.add('oculto');

  var lista = d.historial.slice();
  lista.sort(function (a, b) { return a.fecha < b.fecha ? -1 : 1; });

  var html = '';
  for (var i = 0; i < lista.length; i++) {
    html += '<tr><td>' + formatoFecha(lista[i].fecha) + '</td><td>' + limpiar(lista[i].evento) + '</td><td>' + lista[i].horas + '</td></tr>';
  }
  html += '<tr><td></td><td><b>Total</b></td><td><b>' + horasCumplidas(d) + '</b></td></tr>';
  el('cuerpoHistorial').innerHTML = html;
}

// ★★★☆☆
function estrellasTexto(cantidad) {
  var texto = '';
  for (var i = 1; i <= 5; i++) { texto += (i <= cantidad ? '★' : '☆'); }
  return texto;
}

function pintarResenas() {
  var lista = leer('resenas', []);
  var html = '';
  for (var i = 0; i < lista.length; i++) {
    var r = lista[i];
    html += '<div class="tarjeta" style="margin-bottom: 12px;">' +
            '<h3>' + limpiar(r.evento) + ' - ' + r.estrellas + (r.estrellas == 1 ? ' estrella' : ' estrellas') + '</h3>' +
            '<p class="fijas">' + estrellasTexto(r.estrellas) + '</p>' +
            '<p>' + limpiar(r.comentario) + '</p><small>' + limpiar(r.autor) + '</small></div>';
  }
  el('listaResenas').innerHTML = html;
}

// El estudiante solo puede reseñar actividades que ya cumplió y que no ha reseñado
function llenarSelectResena() {
  var d = datos();
  var u = usuarioActual();
  var resenas = leer('resenas', []);
  var html = '<option value="">Selecciona un evento</option>';
  var cantidad = 0;

  for (var i = 0; i < d.historial.length; i++) {
    var yaReseno = false;
    for (var j = 0; j < resenas.length; j++) {
      if (resenas[j].correo == u.correo && resenas[j].evento == d.historial[i].evento) { yaReseno = true; }
    }
    if (!yaReseno) {
      html += '<option value="' + limpiar(d.historial[i].evento) + '">' + limpiar(d.historial[i].evento) + '</option>';
      cantidad++;
    }
  }
  el('eventoResena').innerHTML = html;

  // Si no hay nada para reseñar, se bloquea el formulario y se explica por qué
  el('eventoResena').disabled = (cantidad === 0);
  el('botonResena').disabled = (cantidad === 0);
  poner('avisoResena', cantidad === 0 ? 'Cuando cumplas una actividad (o si ya reseñaste todas), podrás dejar otra reseña aquí.' : '');
}

function pintarEstrellas() {
  var botones = document.querySelectorAll('.estrella');
  for (var i = 0; i < botones.length; i++) {
    var numero = parseInt(botones[i].getAttribute('data-valor'), 10);
    if (numero <= puntaje) { botones[i].classList.add('activa'); }
    else { botones[i].classList.remove('activa'); }
  }
}

function iniciarHistorial() {
  pintarHistorial();
  pintarResenas();
  llenarSelectResena();

  // Botón "Dejar una reseña": baja hasta el formulario
  el('botonIrResena').onclick = function () {
    el('resenas').scrollIntoView({ behavior: 'smooth' });
  };

  // Las 5 estrellas
  var botones = document.querySelectorAll('.estrella');
  for (var i = 0; i < botones.length; i++) {
    botones[i].onclick = function () {
      puntaje = parseInt(this.getAttribute('data-valor'), 10);
      pintarEstrellas();
    };
  }

  // Botón "Publicar reseña"
  el('formResena').onsubmit = function (evento) {
    evento.preventDefault();
    var elegido = el('eventoResena').value;
    var comentario = valor('comentarioResena');

    var errores = 0;
    if (marcar('errorEventoResena', elegido === '' ? 'Elige el evento que quieres reseñar.' : '')) { errores++; }
    if (marcar('errorPuntaje', puntaje === 0 ? 'Elige de 1 a 5 estrellas.' : '')) { errores++; }
    if (marcar('errorComentario', comentario.length < 5 ? 'Escribe un comentario (mínimo 5 caracteres).' : '')) { errores++; }
    if (errores > 0) { return; }

    var u = usuarioActual();
    var lista = leer('resenas', []);
    lista.unshift({ evento: elegido, estrellas: puntaje, comentario: comentario, autor: nombreCorto(u.nombre), correo: u.correo });
    guardar('resenas', lista);

    puntaje = 0;
    pintarEstrellas();
    el('comentarioResena').value = '';
    pintarResenas();
    llenarSelectResena();
    mostrarMensaje('Tu reseña se publicó. ¡Gracias por opinar!');
  };
}

/* ---------- Semestre: línea de tiempo, cortes y Top 10 ---------- */

// Horas de un estudiante del Top 10 en el periodo elegido
function hlDe(estudiante, periodo) {
  if (periodo == 'todos') { return estudiante.hl[0] + estudiante.hl[1] + estudiante.hl[2]; }
  return estudiante.hl[parseInt(periodo, 10)];
}

function tarjetaPodio(fila, puesto) {
  return '<div class="puesto' + (puesto == 1 ? ' primero' : '') + '">' +
         '<p class="nota">' + puesto + '.° puesto</p>' +
         '<h3>' + limpiar(fila.ini) + (fila.yo ? ' (tú)' : '') + '</h3>' +
         '<p class="nota">' + limpiar(fila.programa) + ' - ' + fila.semestre + '.° semestre</p>' +
         '<div class="numero">' + fila.total + ' HL</div></div>';
}

function pintarTop10() {
  var periodo = el('periodoTop').value;
  var u = usuarioActual();

  // 1. Lista con TODOS los usuarios registrados en la página
  var usuarios = listaUsuarios();
  var lista = [];
  var yo = null;
  for (var i = 0; i < usuarios.length; i++) {
    var d = leer('datos_' + usuarios[i].correo, { inscritos: [], historial: [] });
    var horas = horasCumplidas(d);
    if (periodo == '0' || periodo == '1') { horas = 0; }   // las horas reales son del semestre 2026-2
    var fila = {
      ini: iniciales(usuarios[i].nombre),
      programa: usuarios[i].programa,
      semestre: usuarios[i].semestre,
      total: horas,
      yo: (u !== null && usuarios[i].correo == u.correo)
    };
    if (fila.yo) { yo = fila; }
    lista.push(fila);
  }

  // 2. Se ordena de mayor a menor y se toman los 10 primeros
  lista.sort(function (a, b) { return b.total - a.total; });
  var top = lista.slice(0, 10);

  // 3. Podio (2.°, 1.° y 3.°); si hay menos de 3 personas, solo se muestran las que existen
  var podio = '';
  if (top[1]) { podio += tarjetaPodio(top[1], 2); }
  if (top[0]) { podio += tarjetaPodio(top[0], 1); }
  if (top[2]) { podio += tarjetaPodio(top[2], 3); }
  el('podio').innerHTML = podio;

  // 4. Tabla con los puestos 4 al 10
  var html = '';
  for (var p = 3; p < top.length; p++) {
    html += '<tr' + (top[p].yo ? ' class="yo"' : '') + '><td>' + (p + 1) + '.°</td><td>' + limpiar(top[p].ini) + (top[p].yo ? ' (tú)' : '') +
            '</td><td>' + limpiar(top[p].programa) + '</td><td>' + top[p].semestre + '.°</td><td>' + top[p].total + '</td></tr>';
  }
  el('cuerpoTop').innerHTML = html;

  // 5. Posición del usuario
  if (yo === null) { poner('miPosicion', ''); return; }
  var puesto = lista.indexOf(yo) + 1;
  var texto;
  if (puesto <= 10) {
    texto = 'Tu posición: ' + puesto + '.° con ' + yo.total + ' HL. ¡Estás en el Top 10!';
  } else {
    texto = 'Tu posición: fuera del Top 10, con ' + yo.total + ' HL. Para entrar necesitas más de ' + top[9].total + ' HL.';
  }
  poner('miPosicion', texto);
}

function iniciarSemestre() {
  pintarCortes('cortes');

  var html = '';
  for (var i = 0; i < PERIODOS_TOP.length; i++) {
    html += '<option value="' + PERIODOS_TOP[i].valor + '">' + PERIODOS_TOP[i].texto + '</option>';
  }
  el('periodoTop').innerHTML = html;
  pintarTop10();

  // Botón "Aplicar": vuelve a calcular el Top 10 con el periodo elegido
  el('botonAplicar').onclick = pintarTop10;
}

/* ---------- Ayuda: reportar un problema ---------- */
function iniciarAyuda() {
  el('formReporte').onsubmit = function (evento) {
    evento.preventDefault();
    var tipo = el('tipoProblema').value;
    var afectado = valor('afectado');
    var descripcion = valor('descripcion');

    var errores = 0;
    if (marcar('errorAfectado', afectado === '' ? 'Indica el evento o la sección afectada.' : '')) { errores++; }
    if (marcar('errorDescripcion', descripcion.length < 10 ? 'Escribe una descripción de lo que pasó (mínimo 10 caracteres).' : '')) { errores++; }
    if (errores > 0) { return; }

    var reportes = leer('reportes', []);
    reportes.push({ numero: reportes.length + 1, correo: usuarioActual().correo, tipo: tipo, afectado: afectado, descripcion: descripcion, fecha: hoy() });
    guardar('reportes', reportes);

    el('afectado').value = '';
    el('descripcion').value = '';
    poner('numeroReporte', 'Reporte n.° ' + reportes.length + ' - ' + formatoFecha(hoy()) + '.');
    el('confirmacion').classList.remove('oculto');
    el('confirmacion').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  };
}


/* =====================================================
   8. LO QUE SE HACE EN TODAS LAS PÁGINAS
   ===================================================== */

function textoBotonTema() {
  var oscuro = document.body.classList.contains('oscuro');
  poner('botonTema', oscuro ? 'Modo claro' : 'Modo oscuro');
}

function iniciarComun(pagina) {
  sembrarDatos();

  // Tema claro u oscuro (se recuerda la última elección)
  if (localStorage.getItem('tema') == 'oscuro') { document.body.classList.add('oscuro'); }
  textoBotonTema();
  el('botonTema').onclick = function () {
    document.body.classList.toggle('oscuro');
    localStorage.setItem('tema', document.body.classList.contains('oscuro') ? 'oscuro' : 'claro');
    textoBotonTema();
  };

  // Páginas públicas: login y registro. Todas las demás exigen sesión.
  var publica = (pagina == 'login' || pagina == 'registro');
  var usuario = usuarioActual();
  if (publica && usuario !== null) { irA('inicio'); return false; }
  if (!publica && usuario === null) { irA('login'); return false; }

  if (!publica) {
    poner('nombreUsuario', primerNombre(usuario.nombre));
    poner('avatar', usuario.nombre.charAt(0).toUpperCase());
    el('botonSalir').onclick = cerrarSesion;
  }
  return true;
}


/* =====================================================
   9. ARRANQUE: todas las páginas viven en este mismo archivo.
   La dirección (#login, #inicio, #perfil...) decide cuál se muestra.
   ===================================================== */

var registroNuevo = '';   // correo recién registrado (para mostrarlo en el login)

var PAGINAS = ['login', 'registro', 'inicio', 'perfil', 'lugares', 'historial', 'semestre', 'mapa', 'ayuda'];

var INICIADORES = {
  login: iniciarLogin, registro: iniciarRegistro, inicio: iniciarInicio, perfil: iniciarPerfil,
  lugares: iniciarLugares, historial: iniciarHistorial, semestre: iniciarSemestre, ayuda: iniciarAyuda
};

// Cambia de página
function irA(pagina) {
  if (location.hash == '#' + pagina) { mostrar(); }
  else { location.hash = '#' + pagina; }
}

function mostrar() {
  var pagina = location.hash.replace('#', '');
  if (PAGINAS.indexOf(pagina) == -1) { pagina = (usuarioActual() !== null) ? 'inicio' : 'login'; }
  var publica = (pagina == 'login' || pagina == 'registro');

  // Menú y datos del usuario solo se ven con sesión iniciada
  el('menu').classList.toggle('oculto', publica);
  el('zonaUsuario').classList.toggle('oculto', publica);
  var enlaces = el('menu').getElementsByTagName('a');
  for (var i = 0; i < enlaces.length; i++) {
    enlaces[i].classList.toggle('activo', enlaces[i].getAttribute('data-p') == pagina);
  }

  if (!iniciarComun(pagina)) { return; }

  document.body.setAttribute('data-pagina', pagina);
  el('vista').innerHTML = document.getElementById('t-' + pagina).innerHTML;
  window.scrollTo(0, 0);
  if (INICIADORES[pagina]) { INICIADORES[pagina](); }
}

window.addEventListener('hashchange', mostrar);
mostrar();

